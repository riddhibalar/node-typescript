import express  from "express";
import { ItemsRouter } from "./items/items.router"

const app : express.Application = express();
app.use(express.json());

app.use('/',ItemsRouter)

app.listen(5000,()=>console.log("Server sarted")) 