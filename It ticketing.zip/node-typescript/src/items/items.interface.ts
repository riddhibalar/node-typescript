import { Item } from "./item.interface";

export interface Items {
    [key: number]: Item;
}